var jsonData = [
    {
        "q" : "1.The common element which describe the web page, is ?",
        "opt1" : "Heading",
        "opt2" : "Paragraph",
        "opt3" : "All of these",
        "answer" : "All of these"
    },
    {
        "q" : "2.HTML stands for?",
        "opt1" : "Hyper Text Markup Language",
        "opt2" : "High Text Markup Language",
        "opt3" : "Hyper Tabular Markup Language",
        "answer" : "Hyper Text Markup Language"
    },
    {
        "q" : "3.Which of the following tag is used to mark a begining of paragraph ?",
        "opt1" : "TD",
        "opt2" : "br",
        "opt3" : "P",
        "answer" : "P"
    },
    {
        "q" : "4.From which tag descriptive list starts ?",
        "opt1" : "LL",
        "opt2" : "DL",
        "opt3" : "DD",
        "answer" : "DL"
    },
    {
        "q" : "5.Correct HTML tag for the largest heading is _____",
        "opt1" : "h1",
        "opt2" : "h6",
        "opt3" : "heading",
        "answer" : "h1"
    },
    {
        "q" : "6.Who is making the Web standards?",
        "opt1" : "Microsoft",
        "opt2" : "Mozilla",
        "opt3" : "World Wide Web Consortium",
        "answer" : "World Wide Web Consortium" 
    },
    {
        "q" : "7.What is the correct HTML element for inserting a line break?",
        "opt1" : "br",
        "opt2" : "lb",
        "opt3" : "break",
        "answer" : "br" 
    },
    {
        "q" : "8.Which character is used to indicate an end tag",
        "opt1" : "*",
        "opt2" : "<",
        "opt3" : "/",
        "answer" : "/" 
    },
    {
        "q" : "9.Which HTML element defines the title of a document?",
        "opt1" : "title",
        "opt2" : "head",
        "opt3" : "meta",
        "answer" : "title" 
    },
    {
        "q" : "10.What is the correct HTML element for playing video files",
        "opt1" : "movie",
        "opt2" : "media",
        "opt3" : "video",
        "answer" : "video" 
    }
  
];